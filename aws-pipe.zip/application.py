from flask import Flask

application = Flask(__name__)

@application.route("/")
def hello():
    return "Welcome to UNIQUE88 Sample Python Flask App"

@application.route("/hello")
def hello():
    return "Hello from second page to UNIQUE88 ! "

if __name__ == "__main__":
    application.run(port=5000, debug=True)
